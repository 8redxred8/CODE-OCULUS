using Godot;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Net.NetworkInformation;

namespace StateMachine
{
    public class StateMachine : Node
    {
        private readonly Dictionary<string, State> availableStates = new Dictionary<string, State>();
        private State CurrentState { get; set; }
        private State FirstState { get; set; }
        public State PreviousState { get; set; }

        public override void _Ready()
        {
            base._Ready();
            foreach (var child in GetChildren())
            {
                if(!(child is State state)) continue;
                if(availableStates.Count == 0)
                {
                    FirstState = state;
                }
                availableStates[state.Name] = state;
                state.StateMachine = this;

            }
            foreach (KeyValuePair<string, State> keyValuePair in availableStates)
            {
                GD.Print("State = ", keyValuePair.Key.ToString());
            }

        }
        public override void _Process(float delta)
        {
            base._Process(delta);
            if (CurrentState == null)
            {
                ChangeState(FirstState);
            }
            CurrentState.OnProcess?.Invoke(delta);
        }
        public override void _PhysicsProcess(float delta)
        {
            base._PhysicsProcess(delta);
            if (CurrentState == null)
            {
                ChangeState(FirstState);
            }
            CurrentState.OnPhysicsProcess?.Invoke(delta);

        }
        public void SetPreviousState(State name)
        {
            PreviousState = name;
        }
        private void ChangeState(State NewState) 
        {
            if (NewState == null)
            {
                GD.PrintErr("NULL STATE!");
            }
            CurrentState?.OnExit?.Invoke();
            CurrentState = NewState;
            NewState.OnEnter?.Invoke();
        }
        public void ChangeState(string name)
        {
            ChangeState(availableStates[name]);
        }

        public override void _UnhandledInput(InputEvent @event)
        {
            base._UnhandledInput(@event);
            CurrentState?.OnInput?.Invoke(@event);
        }

    }
}
