
using Godot;
using System;
using static CODE_OCULUS.Part1.P1Globals;
using static CODE_OCULUS.Part1.P1Areas;
using static CODE_OCULUS.Part1.P1Camera;

namespace CODE_OCULUS
{
    namespace Part1
    {


        // General Globals for Part1
        public static class P1Globals
        {
            public static Part1 part1 = new Part1();

            public static Node part1_Node;
            public static KinematicBody2D part1_Player;
            public static CanvasModulate part1_Modulate;
            public static Color part1_PreviousColorModulate;

            public static bool parkingLot_Enter = false;
            public static bool forest_Enter = false;

            public static Transform2D playerCameraPos;
        }
        //
        public static class P1Camera
        {
            public static Camera2D playerCamera;
            public static Camera2D forestCamera;
            public static Camera2D parkingLotCamera;
            public static Camera2D transitionCamera;

            public static Camera2D previousCamera;
            public static Vector2 previousCameraPos;

            public static Tween tweenCamera;

            public static Node2D transitionCameraNode;

            public static bool transitioning = false;

        }
        // Areas and their properties for Part1
        public static class P1Areas
        {
            const float fzoom = 0.1f;
            const float plzoom = 0.7f;
            const float defzoom = 0.15f;

            public static Area2D Forest;
            public static Area2D ParkingLot;

            public static Vector2 F_Zoom = new Vector2(fzoom, fzoom);
            public static Vector2 PL_Zoom = new Vector2(plzoom, plzoom);
            public static Vector2 DEF_Zoom = new Vector2(defzoom, defzoom);
        }

        // Part1 Main Code
        public class Part1 : Node
        {
            public Node[] birdEnemies;
            public override void _Ready()
            {
                part1_Node = this;
                part1_Modulate = GetNode<CanvasModulate>(nameof(CanvasModulate));
                part1_PreviousColorModulate = part1_Modulate.Color;
                part1_Player = GetNode<KinematicBody2D>("World/Player/Player");

                Forest = GetNode<Area2D>("Areas/Forest");
                ParkingLot = GetNode<Area2D>("Areas/ParkingLot");

                playerCamera = part1_Player.GetNode<Camera2D>(nameof(Camera2D));
                forestCamera = Forest.GetNode<Camera2D>(nameof(Camera2D));
                parkingLotCamera = ParkingLot.GetNode<Camera2D>(nameof(Camera2D));

                transitionCameraNode = GetNode<Node2D>("TransitionCamera");
                transitionCamera = transitionCameraNode.GetNode<Camera2D>(nameof(Camera2D));

                previousCamera = playerCamera;

                tweenCamera = transitionCameraNode.GetNode<Tween>(nameof(Tween));

                part1_Modulate.Color = Color.ColorN("Black");

                // LOAD ENEMIES

               
            }
            private Vector2 _newPos;
            private Camera2D _newCam;
            public override void _Process(float delta)
            {
                base._Process(delta);
            }

            public void SwitchCameras(Camera2D from, Camera2D to)
            {
                from.Current = false;
                to.Current = true;
            }
            public async void CameraTransition(Camera2D from, Camera2D to, float duration)
            {
                
                if (!transitioning)
                {
                    transitionCamera.GlobalTransform = from.GlobalTransform;
                    transitionCamera.Zoom = from.Zoom;
                    transitionCamera.Offset = from.Offset;
                }
                else
                    from = transitionCamera;

                transitionCamera.Current = true;

                tweenCamera.RemoveAll();
                transitioning = true;

                tweenCamera.InterpolateProperty(transitionCamera, "global_transform", transitionCamera.GlobalTransform, to.GlobalTransform, 
                    duration, Tween.TransitionType.Quint, Tween.EaseType.Out);
                tweenCamera.InterpolateProperty(transitionCamera, "zoom", transitionCamera.Zoom, to.Zoom,
                    duration, Tween.TransitionType.Quint, Tween.EaseType.Out);
                tweenCamera.InterpolateProperty(transitionCamera, "offset", transitionCamera.Offset, to.Offset,
                    duration, Tween.TransitionType.Quint, Tween.EaseType.Out);
                if (to.GetParent().Name == "Forest")
                    tweenCamera.InterpolateProperty(part1_Modulate, "color", part1_Modulate.Color, Color.ColorN("Black"), 
                        duration, Tween.TransitionType.Elastic, Tween.EaseType.Out);
                else
                    tweenCamera.InterpolateProperty(part1_Modulate, "color", part1_Modulate.Color, part1_PreviousColorModulate,
                        duration, Tween.TransitionType.Elastic, Tween.EaseType.Out);

                tweenCamera.Start();

                await ToSignal(tweenCamera, "tween_all_completed");
                transitioning = false;
                playerCamera.GlobalPosition = transitionCamera.GlobalPosition;
                to.Current = true;
                playerCamera.GlobalPosition = part1_Player.GlobalPosition;
                GD.Print(playerCamera.GlobalPosition);

                //playerCamera.SmoothingSpeed = 5f;
            }

            // PART 1 SIGNALS
            public void _on_Forest_area_entered(Area2D area) { forest_Enter = true; }
            public void _on_Forest_area_exited(Area2D area) { forest_Enter = false; }

            public void _on_ParkingLot_area_entered(Area2D area) { parkingLot_Enter = true; }
            public void _on_ParkingLot_area_exited(Area2D area) { parkingLot_Enter = false; }

        }
    }
}
