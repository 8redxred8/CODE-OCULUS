using Godot;
using System;
using StateMachine;

namespace CODE_OCULUS
{
    namespace Part1.Camera.States
    {
        public class CameraState : State
        {
            protected Camera camera = new Camera();
            
            public override void _Ready()
            {
                base._Ready();
                camera = Owner as Camera;
            }
        }
    }
}

