using Godot;
using System;
using StateMachine;
using static CODE_OCULUS.Part1.P1Globals;
using static CODE_OCULUS.Part1.P1Areas;
using static CODE_OCULUS.Part1.P1Camera;

namespace CODE_OCULUS
{
    namespace Part1.Camera.States
    {
        public class FollowPlayerState : State
        {

            public override void _Ready()
            {
                base._Ready();
                OnEnter += () =>
                {
                    GD.Print("on follow player");
                    //playerCamera.SmoothingSpeed = 1f;
                    GD.Print(playerCamera.GlobalPosition);
                    part1.CameraTransition(previousCamera, playerCamera, 1.5f);

                };
                OnExit += () =>
                {
                    previousCamera = playerCamera;
                };
                OnProcess += Process;
            }
            public void Process(float delta)
            {
                
                if (parkingLot_Enter)
                    StateMachine?.ChangeState("ParkingLotState");

                if (forest_Enter)
                    StateMachine?.ChangeState("ForestState");
            }
        }
    }
}
