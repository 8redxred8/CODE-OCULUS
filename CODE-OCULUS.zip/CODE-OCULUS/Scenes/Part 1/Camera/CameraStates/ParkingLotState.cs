using Godot;
using StateMachine;
using System;
using static CODE_OCULUS.Part1.P1Globals;
using static CODE_OCULUS.Part1.P1Areas;
using static CODE_OCULUS.Part1.P1Camera;
using static CODE_OCULUS.Player.PlayerGlobals;


namespace CODE_OCULUS
{
    namespace Part1.Camera.States
    {
        public class ParkingLotState : State
        {

            public override void _Ready()
            {
                base._Ready();
                OnEnter += () =>
                {
                    GD.Print("on parking lot");
                    part1.CameraTransition(previousCamera, parkingLotCamera, 2f);
                };
                OnExit += () =>
                {
                    previousCamera = parkingLotCamera;
                    GD.Print(playerCamera.GlobalPosition);
                };
                OnProcess += Process;
            }
            public void Process(float delta)
            {
                if (forest_Enter)
                    StateMachine?.ChangeState("ForestState");
                if (!parkingLot_Enter)
                    StateMachine?.ChangeState("FollowPlayer");
            }
        }
    }
}
