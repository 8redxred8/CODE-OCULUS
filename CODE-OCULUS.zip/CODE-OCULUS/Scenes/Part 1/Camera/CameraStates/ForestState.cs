using Godot;
using StateMachine;
using System;
using static CODE_OCULUS.Part1.P1Globals;
using static CODE_OCULUS.Part1.P1Areas;
using static CODE_OCULUS.Part1.P1Camera;
using static CODE_OCULUS.Player.PlayerGlobals;


namespace CODE_OCULUS
{
    namespace Part1.Camera.States
    {
        public class ForestState : State
        {

            public override void _Ready()
            {
                base._Ready();
                OnEnter += () =>
                {
                    GD.Print("on forest");
                    part1.CameraTransition(previousCamera, forestCamera, 2f);
                };
                OnExit += () =>
                {
                    previousCamera = forestCamera;
                };
                OnProcess += Process;
            }
            public void Process(float delta)
            {

                if (parkingLot_Enter)
                    StateMachine?.ChangeState("ParkingLotState");
                if(!forest_Enter)
                    StateMachine?.ChangeState("FollowPlayer");
            }
        }
    }
}
