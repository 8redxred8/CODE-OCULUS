using Godot;
using System;

namespace CODE_OCULUS
{
    namespace Part1.Camera
    {

        public class Camera : Camera2D
        {

            public override void _Ready()
            {
                base._Ready();
            }
        }
    }
}
