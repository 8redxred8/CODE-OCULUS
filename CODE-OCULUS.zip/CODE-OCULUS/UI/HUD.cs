using Godot;
using static CODE_OCULUS.HUD.HUDGlobals;
using System;

namespace CODE_OCULUS
{
    namespace HUD
    {
        public static class HUDGlobals
        {
            public static HUD _hud;
            public static TextureProgress playerHealthBar;
            public static TextureProgress enemyHealthBar;
            

        }
        public class HUD : Node
        {
            private Tween tween;
            public override void _Ready()
            {
                base._Ready();
                _hud = this;

                playerHealthBar = GetNode<TextureProgress>("PlayerHealthBar");
                enemyHealthBar = GetNode<TextureProgress>("EnemyHealthBar");
                tween = GetNode<Tween>(nameof(Tween));
            }
            
            public void ChangeValues(string body, float value)
            {
                if(body == "player")
                {
                    tween.InterpolateProperty(playerHealthBar, "value", playerHealthBar.Value, value, 0.5f, Tween.TransitionType.Cubic, Tween.EaseType.Out);
                    tween.Start();
                }
                if (body == "enemy")
                {
                    
                    tween.InterpolateProperty(enemyHealthBar, "value", enemyHealthBar.Value, value, 0.5f, Tween.TransitionType.Cubic, Tween.EaseType.Out);
                    tween.Start();
                }
            }
            public void ShowOrHide(string body, bool show)
            {

            }
        }
    }
}