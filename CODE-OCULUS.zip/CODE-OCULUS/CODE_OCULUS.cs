using Godot;
using System;

namespace CODE_OCULUS
{
    public static class Globals
    {
        public static Player.Player player = new Player.Player();
    }
}