using Godot;
using System;
using StateMachine;

namespace CODE_OCULUS
{
    namespace Player.States
    {
        public class IdleState : PlayerState
        {
            public override void _Ready()
            {
                base._Ready();
                OnEnter += () =>
                {
                    GD.Print("on idle");
                    player.CurrentTop = "idle";
                    player.CurrentBottom = "idle";
                    player.CurrentFocti = "idle";
                    player.CurrentBocti = "idle";
                    player.CurrentFX = "RESET";
                    player.CurrentAnimSpeed = 0.3f;

                };
                OnExit += () =>
                {
                    StateMachine?.SetPreviousState(this);

                };

                OnPhysicsProcess += PhysicsProcess;
            }

            private void PhysicsProcess(float delta)
            {
                if (!player.IsPlayerActive) return;

                player.StatesInput(StateMachine, delta, "PlayerIdle");

            }
        }
    }
}
