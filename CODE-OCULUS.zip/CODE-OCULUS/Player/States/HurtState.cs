using Godot;
using System;
using StateMachine;
using static CODE_OCULUS.Player.PlayerGlobals;

namespace CODE_OCULUS
{
    namespace Player.States
    {
        public class HurtState : State
        {
            public override void _Ready()
            {
                base._Ready();
                OnEnter += () =>
                {
                    player.CurrentTop = "hurt";
                    player.CurrentBottom = "hurt";
                    player.CurrentBocti = "hurt";
                    player.CurrentFocti = "hurt";
                    player.CurrentFX = "RESET";

                };
                OnProcess += Process;
            }
            public void Process(float delta)
            {
                player.Move(Vector2.Zero, delta);

                if (!topAnimState.IsPlaying())
                {
                    StateMachine?.ChangeState("IdleState");
                }
            }
        }
    }
}