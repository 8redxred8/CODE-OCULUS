using Godot;
using System;
using StateMachine;
using static CODE_OCULUS.Player.PlayerGlobals;

namespace CODE_OCULUS
{
    namespace Player.States
    {
        public class DashState : State
        {
            public override void _Ready()
            {
                base._Ready();
                OnEnter += () =>
                {
                    player.CurrentTop = "dash";
                    player.CurrentBottom = "dash";
                    player.CurrentFX = "dash";

                    player.CurrentAnimSpeed = 1.2f;
                    isDashDone = false;
                };
                OnPhysicsProcess += PhysicsProcess;
            }
            public void PhysicsProcess(float delta)
            {
                player.StatesInput(StateMachine, delta, "PlayerDash");
                var direction = new Vector2(Input.GetActionStrength("move_right") - Input.GetActionStrength("move_left"), Input.GetActionStrength("move_down") - Input.GetActionStrength("move_up")).Normalized();

                player.Move(direction * 1.7f, delta);
            }
        }
    }
}
