using Godot;
using System;
using StateMachine;
using static CODE_OCULUS.Player.PlayerGlobals;

namespace CODE_OCULUS
{
    namespace Player.States
    {
        public class SprintState : PlayerState
        {
            public override void _Ready()
            {
                base._Ready();
                OnEnter += () =>
                {
                    GD.Print("on sprint");
                    currentSpeed = runSpeed;

                    player.CurrentTop = "run";
                    player.CurrentBottom = "run";
                    player.CurrentFX = "RESET";
                    player.CurrentAnimSpeed = 1f;


                };
                OnExit += () =>
                {
                    StateMachine?.SetPreviousState(this);

                };

                OnPhysicsProcess += PhysicsProcess;
            }

            private void PhysicsProcess(float delta)
            {
                if (!player.IsPlayerActive) return;

                var direction = new Vector2(Input.GetActionStrength("move_right") - Input.GetActionStrength("move_left"), Input.GetActionStrength("move_down") - Input.GetActionStrength("move_up")).Normalized();

                player.Move(direction, delta);

                player.StatesInput(StateMachine, delta, "PlayerSprint");



            }
        }
    }
}