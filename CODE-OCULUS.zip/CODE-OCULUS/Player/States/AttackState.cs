using Godot;
using System;
using StateMachine;
using System.Diagnostics.Contracts;
using static CODE_OCULUS.Player.PlayerGlobals;
namespace CODE_OCULUS
{
    namespace Player.States
    {
        public class AttackState : State
        {
            [Export] private string animation;
            [Export] private string nextAnim;
            public override void _Ready()
            {
                base._Ready();
                OnEnter += () =>
                {
                    GD.Print("on attack1");
                    player.CurrentTop = animation;
                    player.CurrentBottom = animation;
                    player.CurrentFX = animation;
                    player.CurrentAnimSpeed = 1.5f;

                    canInput = false;
                    isAttackDone = false;
                    player.nextAnim = nextAnim;

                    player_Hitbox.Disabled = false;


                };
                OnExit += () =>
                {
                    player_Hitbox.Disabled = true;
                };

                OnPhysicsProcess += PhysicsProcess;
            }
            public void PhysicsProcess(float delta)
            {

                player.StatesInput(StateMachine, delta,"PlayerAttack");
                var direction = new Vector2(Input.GetActionStrength("move_right") - Input.GetActionStrength("move_left"), Input.GetActionStrength("move_down") - Input.GetActionStrength("move_up")).Normalized();

                player.Move(direction * 0.6f, delta);
            }

        }
    }
}
