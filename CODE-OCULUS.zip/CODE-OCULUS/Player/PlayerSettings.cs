using Godot;
using System;

namespace CODE_OCULUS
{
    public static class PlayerSettings
    {

    }


}
