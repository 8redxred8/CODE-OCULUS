using Bird.Settings;
using Godot;
using System;
using static CODE_OCULUS.Player.PlayerGlobals;

namespace CODE_OCULUS
{
    namespace Player
    {
        public static class PlayerGlobals
        {
            public static Player player;
            public static StateMachine.StateMachine player_SM;
            //
            public static KinematicBody2D player_Node;
            public static CollisionShape2D player_Collision;
            public static CollisionShape2D player_Hitbox;
            public static Area2D player_Hurtbox;
            //
            // PLAYER GLOBAL VARS
            public static float player_MaxHealth = 100f;
            public static float player_Health = 100f;
            //
            public static float player_MaxStamina = 100f;
            public static float player_Stamina = 100f;
            //
            public static float player_Damage = 15f;
            //
            // CHECKERS
            public static bool active;
            //
            public static bool canInput;
            public static bool isAttackDone;
            public static bool isDashDone = true;

            //
            // PROPERTIES
            [Export] public static float Friction = 130f;
            [Export] public static float Acceleration = 350f;
            [Export] public static float AttackAcceleration = 250f;
            //
            [Export] public static float walkSpeed = 20f;
            [Export] public static float runSpeed = 60f;
            [Export] public static float currentSpeed = 0f;
            //
            // ANIMATIONS
            public static AnimationTree topAnimTree; public static AnimationNodeStateMachinePlayback topAnimState;
            public static AnimationTree bottomAnimTree; public static AnimationNodeStateMachinePlayback bottomAnimState;
            public static AnimationTree foctiAnimTree; public static AnimationNodeStateMachinePlayback foctiAnimState;
            public static AnimationTree boctiAnimTree; public static AnimationNodeStateMachinePlayback boctiAnimState;
            public static AnimationTree fxAnimTree; public static AnimationNodeStateMachinePlayback fxAnimState;


        }
        public class Player : KinematicBody2D
        {
            private string currentTop;
            private string currentBottom;
            private string currentFocti;
            private string currentBocti;
            private string currentFX;
            private float currentAnimSpeed;
            // = = = = = = = = = = = = //
            public float velocity;
            public float currentVelocity;
            public Vector2 scale;
            public float checkDirection;

            // = = = = = = = = = = = = //
            public float Speed { get; private set; }
            public Vector2 Velocity { get; private set; }
            public Vector2 Direction { get; private set; }
            public override void _Ready()
            {
                base._Ready();
                player = this;
                player_Node = this;
                player_Collision = GetNode<CollisionShape2D>(nameof(CollisionShape2D));
                player_Hitbox = GetNode<CollisionShape2D>("PlayerHitbox/" + nameof(CollisionShape2D));
                player_Hurtbox = GetNode<Area2D>("Hurtbox");

                // ANIMATIONS
                topAnimTree = GetNode<AnimationPlayer>("TopAnim").GetNode<AnimationTree>(nameof(AnimationTree));
                bottomAnimTree = GetNode<AnimationPlayer>("BottomAnim").GetNode<AnimationTree>(nameof(AnimationTree));
                foctiAnimTree = GetNode<AnimationPlayer>("FOctiAnim").GetNode<AnimationTree>(nameof(AnimationTree));
                boctiAnimTree = GetNode<AnimationPlayer>("BOctiAnim").GetNode<AnimationTree>(nameof(AnimationTree));
                fxAnimTree = GetNode<AnimationPlayer>("FXAnim").GetNode<AnimationTree>(nameof(AnimationTree));

                topAnimState =
                    (AnimationNodeStateMachinePlayback)topAnimTree.Get("parameters/StateMachine/playback");
                bottomAnimState =
                    (AnimationNodeStateMachinePlayback)bottomAnimTree.Get("parameters/StateMachine/playback");
                foctiAnimState =
                    (AnimationNodeStateMachinePlayback)foctiAnimTree.Get("parameters/StateMachine/playback");
                boctiAnimState =
                    (AnimationNodeStateMachinePlayback)boctiAnimTree.Get("parameters/StateMachine/playback");
                fxAnimState =
                    (AnimationNodeStateMachinePlayback)fxAnimTree.Get("parameters/StateMachine/playback");


                scale = Scale;
                checkDirection = 1;
                IsPlayerActive = true;
                currentAnimSpeed = 1f;
            }
            public override void _PhysicsProcess(float delta)
            {
                base._PhysicsProcess(delta);
            }
            // STATES FOR PLAYER
            public string nextAnim;
            public void StatesInput(StateMachine.StateMachine sm, float delta, string state)
            {
                // IDLE STATE
                if(state == "PlayerIdle")
                {
                    var up = Input.IsActionJustPressed("move_up");
                    var down = Input.IsActionJustPressed("move_down");
                    var right = Input.IsActionJustPressed("move_right");
                    var left = Input.IsActionJustPressed("move_left");

                    if (up || down || right || left)
                    {
                        sm?.ChangeState("PlayerWalk");
                    }
                    if (Input.IsActionJustPressed("left_click"))
                    {
                        sm.ChangeState("PlayerAttack1");
                    }

                }
                //
                // WALK STATE
                if (state == "PlayerWalk")
                {
                    if (Input.IsActionJustPressed("sprint"))
                    {
                        sm.ChangeState("PlayerSprint");
                    }
                    if (Velocity.IsEqualApprox(Vector2.Zero))
                    {
                        sm.ChangeState("PlayerIdle");
                    }

                    if (Input.IsActionJustPressed("left_click"))
                    {
                        sm.ChangeState("PlayerAttack1");
                    }

                }
                //
                // SPRINT STATE
                if (state == "PlayerSprint")
                {
                    if (Input.IsActionJustReleased("sprint"))
                    {
                        sm.ChangeState("PlayerWalk");
                    }

                    if (Input.IsActionJustPressed("left_click"))
                    {
                        sm.ChangeState("PlayerAttack1");
                    }

                }
                //
                // ATTACK STATE
                if (state == "PlayerAttack")
                {
                    if (Input.IsActionJustPressed("left_click") && canInput && nextAnim != "Null")
                    {
                        sm?.ChangeState(nextAnim);
                    }

                    if (isAttackDone && canInput)
                    {
                        sm?.ChangeState(sm.PreviousState.Name);
                    }
                }
                //
                // DASH STATE
                if(Input.IsActionJustPressed("space") && state != "PlayerDash")
                {
                    sm?.ChangeState("PlayerDash");
                }
                //
                if(state == "PlayerDash")
                {
                    if (isDashDone)
                    {
                        sm?.ChangeState(sm.PreviousState.Name);
                    }
                }
                //


            }

            // METHOD TO MOVE THE PLAYER
            public void Move(Vector2 direction, float delta)
            {
                currentVelocity = Velocity.x;
                if (Velocity.x > 0 && checkDirection != 1)
                {
                    Scale = new Vector2(Scale.x * -1, Scale.y);
                    checkDirection = 1;
                }
                if (Velocity.x < 0 && checkDirection != -1)
                {
                    Scale = new Vector2(Scale.x * -1, Scale.y);
                    checkDirection = -1;
                }

                if (direction != Vector2.Zero)
                {
                    Velocity = Velocity.MoveToward(direction * currentSpeed, Acceleration * delta);

                }
                if (direction == Vector2.Zero)
                {
                    Velocity = Velocity.MoveToward(Vector2.Zero, Friction * delta);
                }

                Velocity = MoveAndSlide(Velocity);
            }


            public void CheckHurtbox(StateMachine.StateMachine sm)
            {
                foreach(Area2D i in player_Hurtbox.GetOverlappingAreas())
                {
                    if(i.Name == "BirdHitbox")
                    {
                        sm?.ChangeState("PlayerHurt");
                    }
                }
            }


            public bool IsPlayerActive
            {
                get => active;
                set
                {
                    active = value;
                    Visible = active;
                }
            }

            //
            //
            //
            // ANIMATION GETTERS AND SETTERS
            public string CurrentTop
            {
                get => currentTop;
                set
                {
                    if (currentTop == value) return;
                    currentTop = value;
                    topAnimState.Travel(currentTop);
                }
            }
            public string CurrentBottom
            {
                get => currentBottom;
                set
                {
                    if (currentBottom == value) return;
                    currentBottom = value;
                    bottomAnimState.Travel(currentBottom);
                }
            }
            public string CurrentFocti
            {
                get => currentFocti;
                set
                {
                    if (currentFocti == value) return;
                    currentFocti = value;
                    foctiAnimState.Travel(currentFocti);
                }
            }
            public string CurrentBocti
            {
                get => currentBocti;
                set
                {
                    if (currentBocti == value) return;
                    currentBocti = value;
                    boctiAnimState.Travel(currentBocti);
                }
            }
            public string CurrentFX
            {
                get => currentFX;
                set
                {
                    if (currentFX == value) return;
                    currentFX = value;
                    fxAnimState.Travel(currentFX);
                }
            }
            public float CurrentAnimSpeed
            {
                get => currentAnimSpeed;
                set
                {
                    if (currentAnimSpeed == value) return;
                    currentAnimSpeed = value;

                    topAnimTree.Set("parameters/TimeScale/scale", currentAnimSpeed);
                    bottomAnimTree.Set("parameters/TimeScale/scale", currentAnimSpeed);
                    foctiAnimTree.Set("parameters/TimeScale/scale", currentAnimSpeed);
                    boctiAnimTree.Set("parameters/TimeScale/scale", currentAnimSpeed);
                    fxAnimTree.Set("parameters/TimeScale/scale", currentAnimSpeed);
                }
            }

            public void Attack1Done(bool checka)
            {
                isAttackDone = checka;
            }
            public void DashDone(bool checka)
            {
                isDashDone = checka;
            }
            public void ReadyForInput()
            {
                canInput = true;
            }

        }
    }
}

