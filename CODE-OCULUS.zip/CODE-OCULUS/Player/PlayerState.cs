using Godot;
using System;
using StateMachine;

namespace CODE_OCULUS
{
    namespace Player.States
    {
        public class PlayerState : State
        {
            protected Player player = Globals.player;
            public override void _Ready()
            {
                base._Ready();
                player = Owner as Player;
            }
        }
    }
}

