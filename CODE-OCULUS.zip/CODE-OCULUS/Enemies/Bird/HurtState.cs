using Godot;
using System;
using StateMachine;
using static Bird.BirdGlobals;
using static CODE_OCULUS.HUD.HUDGlobals;

namespace Bird.States
{
    public class HurtState : State
    {
        float time;
        Vector2 velocity;
        public override void _Ready()
        {
            base._Ready();
            OnEnter += () =>
            {
                bird.CurrentAnimation = "hurt";
                animationPlayer.PlaybackSpeed = 1.15f;

                canHurt = false;
                isHurt = false;
                hurtDone = false;

                time = 0;

                velocity = -bird.Velocity;

                birdHealth -= CODE_OCULUS.Player.PlayerGlobals.player_Damage;

                _hud.ChangeValues("enemy" , birdHealth);
                
                
            };
            OnExit += () =>
            {
            };
            OnPhysicsProcess += PhysicsProcess;

        }
        public void PhysicsProcess(float delta)
        {
            time += delta;

            var velocity2 = bird.Velocity.MoveToward(velocity, birdCurrentSpeed * delta * 250f);

            bird.Move(velocity2);
            if(time > 0.5f)
            {
                canHurt = true;
                if (birdHealth <= 0)
                {
                    StateMachine?.ChangeState("DeadState");
                }

                hurtDone = true;
                bird.CheckTarget(StateMachine, "HurtState");
            }
        }
    }
}