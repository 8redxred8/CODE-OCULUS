using Godot;
using System;

namespace Bird.Settings
{
    public static class BirdSettings
    {

        
    }
}
