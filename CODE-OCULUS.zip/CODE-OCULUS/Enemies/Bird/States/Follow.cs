using Godot;
using StateMachine;
using static Bird.BirdGlobals;
using System;
using System.Collections.Generic;

namespace Bird.States
{
    public class Follow : State
    {
        private Vector2 moveVelocity;

        public override void _Ready()
        {
            base._Ready();
            OnEnter += () => 
            { 
                bird.CurrentAnimation = "walk";
                bird.CurrentSignAnimation = "warning";
                canHurt = true;
                chaseTimer.Start();

            };
            OnPhysicsProcess = PhysicsProcess;
            OnExit += () =>
            {
                bird.CurrentSignAnimation = "stop";
            };

        }
        private void PhysicsProcess(float delta)
        {
            bird.CheckHitbox(StateMachine);
            bird.CheckTarget(StateMachine, "FollowState");

            var direction = (Target.GlobalPosition - bird.GlobalPosition).Normalized();
            animationPlayer.PlaybackSpeed = Mathf.Lerp(animationPlayer.PlaybackSpeed, birdRunPlaybackSpeed, 4.0f * delta);

            //GD.Print("on follow");
            base._PhysicsProcess(delta);
            if (chaseTimer.IsStopped())
            {
                StateMachine?.ChangeState("WanderState");
            }
            moveVelocity = moveVelocity.MoveToward(direction * birdRunningSpeed, birdAcceleration * delta);
            bird.Move(moveVelocity);


        }
    }
}
