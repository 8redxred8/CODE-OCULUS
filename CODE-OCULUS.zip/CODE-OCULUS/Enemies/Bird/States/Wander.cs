using Godot;
using StateMachine;
using Bird.Settings;
using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using static Bird.BirdGlobals;

namespace Bird.States
{
    public class Wander : State
    {
        private Vector2 moveDirection;
        private Vector2 moveVelocity;
        public override void _Ready()
        {
            base._Ready();

            OnEnter += () =>
            {
                bird.CurrentAnimation = "walk";
                wanderTimer.Start();
                moveDirection = new Vector2((float)GD.RandRange(32, -32), (float)GD.RandRange(32, -32));
                canHurt = true;
                moveVelocity = Vector2.Zero;

            };

            OnPhysicsProcess += PhysicsProcess;

            OnExit += () =>
            {
            };
        }
        private void PhysicsProcess(float delta)
        {
            //GD.Print(interpolate);
            animationPlayer.PlaybackSpeed = Mathf.Lerp(animationPlayer.PlaybackSpeed, birdWanderPlaybackSpeed, 4.0f * delta);
            moveVelocity = bird.Velocity;

            
            bird.CheckTarget(StateMachine, "WanderState");
            bird.CheckHitbox(StateMachine);

            if (wanderTimer.IsStopped())
            {
                StateMachine?.ChangeState("WanderState");
            }
            moveVelocity = moveVelocity.MoveToward(moveDirection.Normalized() * birdDefaultSpeed, birdAcceleration * delta);
            bird.Move(moveVelocity);

        }
    }
}
