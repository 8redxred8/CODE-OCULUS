using Godot;
using StateMachine;
using System;
using static Bird.BirdGlobals;

namespace Bird.States
{
    public class Idle : State
    {
        public override void _Ready()
        {
            base._Ready();
            OnEnter += () => 
            { 
                bird.CurrentAnimation = "idle";
                bird.animationPlayerSpeed = 0.5f;
            };
            OnPhysicsProcess += PhysicsProcess;
        }
        private void PhysicsProcess(float delta)
        {
            bird.Move(Vector2.Zero);
        }

    }
}
