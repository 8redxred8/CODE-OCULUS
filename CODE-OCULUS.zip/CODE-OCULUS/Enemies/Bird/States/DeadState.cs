using Godot;
using System;
using StateMachine;
using static Bird.BirdGlobals;

namespace Bird.States
{
    public class DeadState : State 
    {
        public override void _Ready()
        {
            base._Ready();
            OnEnter += () =>
            {
                bird.Death();
            };
        }

        public void PhysicsProcess(float delta)
        {
        }
    }
}
