using Godot;
using System;
using StateMachine;
using static Bird.BirdGlobals;

namespace Bird
{
    public static class BirdGlobals
    {
        public static Bird bird;
        public static KinematicBody2D Target { get; set; }

        public static AnimationPlayer animationPlayer;
        public static AnimationPlayer signAnimPlayer;


        public static Timer chaseTimer;
        public static Timer wanderTimer;
        public static Timer idleTimer;

        // VECTORS
        //
        public static Vector2 scale;
        //
        public static Vector2 damageSource;
        public static Vector2 knockbackDirection;


        public static float checkDirection;
        public static bool canHurt;
        public static bool isHurt;
        public static bool hurtDone;
        public static bool attackHit;
        public static bool targetDetected;

        // BIRD ATTRIBUTES
        public static float birdHealth = 300f;
        public static float birdMaxHealth = 300f;
        public static float damageReceived;

        [Export] public static float birdCurrentSpeed = 10f;
        [Export] public static float birdDefaultSpeed = 10f;
        [Export] public static float birdRunningSpeed = 50f;
        [Export] public static float birdAcceleration = 100f;

        [Export] public static float birdHitStun = 0;
        [Export] public static float birdKnockbackStrength = 0.1f;

        [Export] public static float birdDamage = 30f;

        [Export] public static float birdRunPlaybackSpeed = 1f;
        [Export] public static float birdWanderPlaybackSpeed = 0.5f;


    }
    public class Bird : KinematicBody2D
    {

        public float animationPlayerSpeed;
        private string currentAnimation;
        private string currentSignAnimation;

        public float Speed { get; private set; }
        public Vector2 MoveDirection { get; set; }
        public Vector2 Velocity { get; set; }


        public override void _Ready()
        {
            base._Ready();
            bird = this;
            chaseTimer = GetNode<Timer>("Timers/ChaseTimer");
            wanderTimer = GetNode<Timer>("Timers/WanderTimer");
            animationPlayer = GetNode<AnimationPlayer>(nameof(AnimationPlayer));

            signAnimPlayer = GetNode<AnimationPlayer>("SignAnims");
            animationPlayerSpeed = GetNode<AnimationPlayer>(nameof(AnimationPlayer)).PlaybackSpeed;

            canHurt = true;

            signAnimPlayer.Play("RESET");

            checkDirection = -1;
            scale = Scale;
            Speed = birdDefaultSpeed;

            
        }
        public string CurrentAnimation
        {
            get => currentAnimation;
            set
            {
                if (currentAnimation == value) return;
                currentAnimation = value;
                animationPlayer.Play(currentAnimation);
            }
        }
        public string CurrentSignAnimation
        {
            get => currentSignAnimation;
            set
            {
                if (currentSignAnimation == value) return;
                currentSignAnimation = value;
                signAnimPlayer.Play(currentSignAnimation);
            }
        }

        public void Move(Vector2 velocity) 
        {
            if (velocity.x > 0 && checkDirection != 1)
            {
                Scale = new Vector2(Scale.x * -1, Scale.y);
                checkDirection = 1;
            }
            if (velocity.x < 0 && checkDirection != -1)
            {
                Scale = new Vector2(Scale.x * -1, Scale.y);
                checkDirection = -1;
            }

            Velocity = MoveAndSlide(velocity);
        }
        public void Death()
        {
            QueueFree();
        }
        public string GetRandomState(int randomStateNum)
        {
            string[] randomStateArray = {"WanderState", "IdleState"};
            return randomStateArray[randomStateNum];
        }

        public override void _PhysicsProcess(float delta)
        {
            base._PhysicsProcess(delta);
        }
        public void CheckHitbox(StateMachine.StateMachine sm)
        {
            foreach(Area2D i in GetNode<Area2D>("Hurtbox").GetOverlappingAreas())
            {
                if (i.Name == "PlayerHitbox" && canHurt)
                {
                    
                    sm?.ChangeState("HurtState");
                }
            }
        }
        public void CheckTarget(StateMachine.StateMachine sm, string state)
        {
            if(state == "WanderState")
            {
                foreach (KinematicBody2D i in GetNode<Area2D>("Detection").GetOverlappingBodies())
                {
                    if (i.IsInGroup("player"))
                    {
                        Target = i;
                        sm?.ChangeState("FollowState");
                    }
                }
            }
            if (state == "FollowState")
            {
                foreach (Area2D i in GetNode<Area2D>("BirdHitbox").GetOverlappingAreas())
                {
                    if (i.Name == "Detection")
                    {
                        sm?.ChangeState("AttackState");
                    }
                }
            }
            if(state == "HurtState")
            {
                foreach (KinematicBody2D i in GetNode<Area2D>("AttackedDetection").GetOverlappingBodies())
                {
                    if (i.IsInGroup("player") && hurtDone && canHurt)
                    {
                        chaseTimer.Start();
                        Target = i;
                        sm?.ChangeState("FollowState");
                    }
                }
            }

        }
        public void CanHurt(bool isHurt)
        {
            canHurt = isHurt;
        }
        public void HurtDone()
        {
            hurtDone = true;
        }
        public void _on_Hurtbox_area_entered(Area2D area)
        {
            if (canHurt)
            {
                isHurt = true;
            }
        }
        public void _on_Hitbox_area_entered(Area2D area)
        {
            attackHit = true;
        }
    }

}
