using Godot;
using System;
using StateMachine;
using static Bird.BirdGlobals;
using static CODE_OCULUS.HUD.HUDGlobals;

namespace Bird.States
{
    public class AttackState : State
    {
        float time = 0;

        public override void _Ready()
        {
            base._Ready();
            OnEnter += () =>
            {
                bird.CurrentAnimation = "attack";

                canHurt = false;
                isHurt = false;
                hurtDone = false;
                attackHit = false;

                time = 0;

                bird.Move(Vector2.Zero);
                animationPlayer.PlaybackSpeed = 1.3f;
            };
            OnPhysicsProcess += PhysicsProcess;

        }
        public void PhysicsProcess(float delta)
        {
            time += delta;

            if(time > 0.3)
            {
                canHurt = true;
            }
            bird.CheckHitbox(StateMachine);
            if(time > 0.7f)
            {
                StateMachine?.ChangeState("FollowState");

            }


        }
    }
}