using Godot;
using System;

public class PlayerHitbox : Area2D
{
    public Vector2 knockback_value = Vector2.Zero;
    public override void _Ready()
    {
        
    }

//  // Called every frame. 'delta' is the elapsed time since the previous frame.
//  public override void _Process(float delta)
//  {
//      
//  }
}
